//
//  main.m
//  AudioConference
//
//  Created by joson zhang on 10/31/14.
//  Copyright (c) 2014 Joson_Zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ACAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ACAppDelegate class]));
    }
}
