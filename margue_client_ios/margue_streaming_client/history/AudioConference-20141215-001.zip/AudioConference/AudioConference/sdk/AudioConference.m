#import "AudioConference.h"

#include <fcntl.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/ioccom.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#import "CCBopenALsound.h"

#define kOutputBus	0
#define kInputBus	1

#pragma mark buffer queue

void*	bq_new()
{
	bufrqueue *p = malloc(sizeof(bufrqueue));
	if (NULL == p) {
		return NULL;
	}
	memset(p, 0, sizeof(bufrqueue));
	return p;
}
void	bq_destroy(bufrqueue *bq) {
	if (NULL != bq) {
		if (NULL != bq->bufr) {
			free(bq);
		}
		free(bq);
	}
}
int		bq_size(bufrqueue *bq) {
	return (NULL == bq) ? -1 : bq->used;
}
int		bq_read(bufrqueue *bq, unsigned char *dst, int len) {
	int n = MIN(len, bq->used);
	if ((NULL == bq) || (NULL == dst) || (len <= 0)) {
		return -1;
	}
	memcpy(dst, bq->bufr, n);
	bq->used -= n;
	if (bq->used > 0) {
		memmove(bq->bufr, bq->bufr+n, bq->used);
	}
	return n;
}
int		bq_write(bufrqueue *bq, unsigned char *data, int len) {
	if ((NULL == bq) || (NULL == data) || (len <= 0)) {
		return -1;
	}
	if (len > (bq->size-bq->used)) {
		unsigned char *p = (unsigned char *)malloc(len+bq->size);
		if (NULL == p) {
			if (bq->used < len) {
				return -2;
			}
			// skip oldest packet
			bq->used -= len;
			memmove(bq->bufr, bq->bufr+len, bq->used);
		} else {
			if (NULL != bq->bufr) {
				memmove(p, bq->bufr, bq->used);
				free(bq->bufr);
			}
			bq->bufr = p;
			bq->size += len;
		}
	}
	memcpy(bq->bufr+bq->used, data, len);
	bq->used += len;
	return len;
}

#pragma mark -

#pragma mark G.711 codec

#define SIGN_BIT	(0x80)	/* Sign bit for a A-law byte. */   

#define QUANT_MASK	(0xf)	/* Quantization field mask. */   

#define NSEGS		(8)		/* Number of A-law segments. */   

#define SEG_SHIFT	(4)		/* Left shift for segment number. */   

#define SEG_MASK	(0x70)	/* Segment field mask. */   



static short seg_end[8] = {
	
	0xFF,  0x1FF,  0x3FF,  0x7FF,
	
	0xFFF, 0x1FFF, 0x3FFF, 0x7FFF
	
};



/* copy from CCITT G.711 specifications */   

unsigned char _u2a[128] = {	/* u- to A-law conversions */
	
	1,   1,   2,   2,   3,   3,   4,   4,   
	
	5,   5,   6,   6,   7,   7,   8,   8,   
	
	9,  10,  11,  12,  13,  14,  15,  16,   
	
	17,  18,  19,  20,  21,  22,  23,  24,   
	
	25,  27,  29,  31,  33,  34,  35,  36,   
	
	37,  38,  39,  40,  41,  42,  43,  44,   
	
	46,  48,  49,  50,  51,  52,  53,  54,   
	
	55,  56,  57,  58,  59,  60,  61,  62,   
	
	64,  65,  66,  67,  68,  69,  70,  71,   
	
	72,  73,  74,  75,  76,  77,  78,  79,   
	
	81,  82,  83,  84,  85,  86,  87,  88,   
	
	89,  90,  91,  92,  93,  94,  95,  96,   
	
	97,  98,  99, 100, 101, 102, 103, 104,   
	
	105, 106, 107, 108, 109, 110, 111, 112,   
	
	113, 114, 115, 116, 117, 118, 119, 120,   
	
	121, 122, 123, 124, 125, 126, 127, 128
	
};

unsigned char _a2u[128] = {	/* A- to u-law conversions */
	
	1,   3,   5,   7,   9,  11,  13,  15,   
	
	16,  17,  18,  19,  20,  21,  22,  23,   
	
	24,  25,  26,  27,  28,  29,  30,  31,   
	
	32,  32,  33,  33,  34,  34,  35,  35,   
	
	36,  37,  38,  39,  40,  41,  42,  43,   
	
	44,  45,  46,  47,  48,  48,  49,  49,   
	
	50,  51,  52,  53,  54,  55,  56,  57,   
	
	58,  59,  60,  61,  62,  63,  64,  64,   
	
	65,  66,  67,  68,  69,  70,  71,  72,   
	
	73,  74,  75,  76,  77,  78,  79,  79,   
	
	80,  81,  82,  83,  84,  85,  86,  87,   
	
	88,  89,  90,  91,  92,  93,  94,  95,   
	
	96,  97,  98,  99, 100, 101, 102, 103,   
	
	104, 105, 106, 107, 108, 109, 110, 111,   
	
	112, 113, 114, 115, 116, 117, 118, 119,   
	
	120, 121, 122, 123, 124, 125, 126, 127};   



static int search(int val, short *table, int size)   

{   
	
	int i;
	
	
	
	for (i=0; i<size; i++) {
		
		if (val <= *table++) {
			
			return (i);
			
		}
		
	}
	
	return (size);
	
}



/*  
 
 * linear2alaw() - Convert a 16-bit linear PCM value to 8-bit A-law  
 
 *  
 
 * linear2alaw() accepts an 16-bit integer and encodes it as A-law data.  
 
 *  
 
 *      Linear Input Code   Compressed Code  
 
 *  ------------------------    ---------------  
 
 *  0000000wxyza            000wxyz  
 
 *  0000001wxyza            001wxyz  
 
 *  000001wxyzab            010wxyz  
 
 *  00001wxyzabc            011wxyz  
 
 *  0001wxyzabcd            100wxyz  
 
 *  001wxyzabcde            101wxyz  
 
 *  01wxyzabcdef            110wxyz  
 
 *  1wxyzabcdefg            111wxyz  
 
 *  
 
 * For further information see John C. Bellamy's Digital Telephony, 1982,  
 
 * John Wiley & Sons, pps 98-111 and 472-476.  
 
 */   

unsigned char linear2alaw(int pcm_val)	/* 2's complement (16-bit range) */

{
	
	int mask;
	
	int seg;
	
	unsigned char aval;
	
	
	
	if (pcm_val >= 0) {
		
		mask = 0xD5;	/* sign (7th) bit = 1 */
		
	} else {
		
		mask = 0x55;	/* sign bit = 0 */
		
		pcm_val = -pcm_val - 8;
		
	}
	
	
	
	/* Convert the scaled magnitude to segment number. */
	
	seg = search(pcm_val, seg_end, 8);
	
	
	
	/* Combine the sign, segment, and quantization bits. */
	
	if (seg >= 8) {	/* out of range, return maximum value. */
		
		return (0x7F ^ mask);
		
	} else {
		
		aval = seg << SEG_SHIFT;
		
		if (seg < 2) {
			
			aval |= (pcm_val >> 4) & QUANT_MASK;
			
		} else {
			
			aval |= (pcm_val >> (seg + 3)) & QUANT_MASK;
			
		}
		
		return (aval ^ mask);
		
	}
	
}



/*  
 
 * alaw2linear() - Convert an A-law value to 16-bit linear PCM  
 
 *  
 
 */

int alaw2linear(unsigned char a_val)

{   
	
	int t;
	
	int seg;
	
	
	
	a_val ^= 0x55;
	
	
	
	t = (a_val & QUANT_MASK) << 4;
	
	seg = ((unsigned)a_val & SEG_MASK) >> SEG_SHIFT;
	
	switch (seg) {
			
		case 0:
			
			t += 8;
			
			break;
			
		case 1:
			
			t += 0x108;
			
			break;
			
		default:
			
			t += 0x108;
			
			t <<= seg - 1;
			
	}
	
	return ((a_val & SIGN_BIT) ? t : -t);
	
}



#define BIAS	(0x84)	/* Bias for linear code. */   



/*  
 
 * linear2ulaw() - Convert a linear PCM value to u-law  
 
 *  
 
 * In order to simplify the encoding process, the original linear magnitude  
 
 * is biased by adding 33 which shifts the encoding range from (0 - 8158) to  
 
 * (33 - 8191). The result can be seen in the following encoding table:  
 
 *  
 
 *  Biased Linear Input Code    Compressed Code  
 
 *  ------------------------    ---------------  
 
 *  00000001wxyza           000wxyz  
 
 *  0000001wxyzab           001wxyz  
 
 *  000001wxyzabc           010wxyz  
 
 *  00001wxyzabcd           011wxyz  
 
 *  0001wxyzabcde           100wxyz  
 
 *  001wxyzabcdef           101wxyz  
 
 *  01wxyzabcdefg           110wxyz  
 
 *  1wxyzabcdefgh           111wxyz  
 
 *  
 
 * Each biased linear code has a leading 1 which identifies the segment  
 
 * number. The value of the segment number is equal to 7 minus the number  
 
 * of leading 0's. The quantization interval is directly available as the  
 
 * four bits wxyz.  * The trailing bits (a - h) are ignored.  
 
 *  
 
 * Ordinarily the complement of the resulting code word is used for  
 
 * transmission, and so the code word is complemented before it is returned.  
 
 *  
 
 * For further information see John C. Bellamy's Digital Telephony, 1982,  
 
 * John Wiley & Sons, pps 98-111 and 472-476.  
 
 */   

unsigned char linear2ulaw(int pcm_val)	/* 2's complement (16-bit range) */   

{   
	
	int mask;
	
	int seg;
	
	unsigned char uval;
	
	
	
	/* Get the sign and the magnitude of the value. */
	
	if (pcm_val < 0) {
		
		pcm_val = BIAS - pcm_val;
		
		mask = 0x7F;
		
	} else {
		
		pcm_val += BIAS;
		
		mask = 0xFF;
		
	}
	
	
	
	/* Convert the scaled magnitude to segment number. */
	
	seg = search(pcm_val, seg_end, 8);
	
	
	
	/*  
	 
	 * Combine the sign, segment, quantization bits;  
	 
	 * and complement the code word.  
	 
	 */
	
	if (seg >= 8) {	/* out of range, return maximum value. */
		
		return (0x7F ^ mask);
		
	} else {
		
		uval = (seg << 4) | ((pcm_val >> (seg + 3)) & 0xF);
		
		return (uval ^ mask);
		
	}
	
}



/*  
 
 * ulaw2linear() - Convert a u-law value to 16-bit linear PCM  
 
 *  
 
 * First, a biased linear code is derived from the code word. An unbiased  
 
 * output can then be obtained by subtracting 33 from the biased code.  
 
 *  
 
 * Note that this function expects to be passed the complement of the  
 
 * original code word. This is in keeping with ISDN conventions.  
 
 */

int ulaw2linear(unsigned char u_val)

{
	
	int t;
	
	
	
	/* Complement to obtain normal u-law value. */
	
	u_val = ~u_val;
	
	
	
	/*  
	 
	 * Extract and bias the quantization bits. Then  
	 
	 * shift up by the segment number and subtract out the bias.  
	 
	 */
	
	t = ((u_val & QUANT_MASK) << 3) + BIAS;
	
	t <<= ((unsigned)u_val & SEG_MASK) >> SEG_SHIFT;
	
	
	
	return ((u_val & SIGN_BIT) ? (BIAS - t) : (t - BIAS));
	
}   



/* A-law to u-law conversion */

unsigned char alaw2ulaw(unsigned char aval)

{
	
	aval &= 0xff;
	
	return ((aval & 0x80) ? (0xFF ^ _a2u[aval ^ 0xD5]) : (0x7F ^ _a2u[aval ^ 0x55]));
	
}



/* u-law to A-law conversion */

unsigned char ulaw2alaw(unsigned char uval)

{
	
	uval &= 0xff;
	
	return ((uval & 0x80) ? (0xD5 ^ (_u2a[0xFF ^ uval] - 1)) : (0x55 ^ (_u2a[0x7F ^ uval] - 1)));
	
}

unsigned char*	ulaw2linear_batch(unsigned char *p, int n)
{
	unsigned char *out = (unsigned char *)malloc(n*2);
	if (NULL != out) {
		for (int i=0; i<n; i++) {
//printf("%.2X(%c) ", p[i], p[i]);
			int x = ulaw2linear(p[i]);
			out[2*i] = x & 0xFF;
			out[2*i+1] = (x & 0xFF00) >> 8;
		}
	}
	return out;
}

#pragma mark Basic protocol define

typedef struct {
	unsigned int	size;
	unsigned char*	data;
	unsigned int	used;
} membufr;

typedef struct {
	unsigned char	start_code;
	unsigned short	length;
	unsigned char	sequence;
	unsigned char	command;
	unsigned char*	data;
} acpacket;

#define S2C_AUDIODATA		0x00
#define S2C_BROADCAST		0x01
#define S2C_CLIENTRESP		0x02

#define C2S_TALK_START		0x00
#define C2S_TALK_STOP		0x01
#define C2S_LISTEN_START	0x02
#define C2S_LISTEN_STOP		0x03
#define C2S_AUDIODATA		0x09

@interface AudioConference()
-(acpacket *)pkt_send:(UInt8)seq cmd:(UInt8)cmd data:(Byte *)data length:(UInt16)length recv:(BOOL)recv;
-(acpacket *)pkt_send:(UInt8)cmd data:(Byte *)data length:(UInt16)length recv:(BOOL)recv;
@end

@implementation AudioConference

@synthesize delegate;
@synthesize bConnected;

#pragma mark socket layer

- (BOOL)sock_connect:(NSString *)host port:(int)port
{
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0) {
		return NO;
	}

	struct hostent *p;
	struct sockaddr_in addr;
	memset(&addr, 0, sizeof(addr));
	addr.sin_len			= sizeof(addr);
	addr.sin_family			= AF_INET;
	addr.sin_port			= htons(port);
	p = gethostbyname([host UTF8String]);
	if (NULL == p) {
		addr.sin_addr.s_addr= inet_addr([host UTF8String]);
	} else {
		memcpy(&addr.sin_addr.s_addr, p->h_addr, p->h_length);
	}
	if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		close(sock);
		return NO;
	}

	bConnected = YES;
    
    return YES;
}
- (void)sock_close
{
	close(sock);
	sock = -1;
	bConnected = NO;
	dispatch_async(dispatch_get_main_queue(), ^{
		if (self.delegate && [self.delegate respondsToSelector:@selector(disconnected:)]) {
			[self.delegate disconnected:self];
		}
	});
}
- (BOOL)sock_send:(Byte *)data length:(int)length
{
	if (sock < 0) {
		return NO;
	}

	while (length > 0) {
		int i = send(sock, data, length, 0);
		if (i < 0) {
			if ((EAGAIN == errno) || (EINTR == errno)) {
				continue;
			}
			[self sock_close];
			return NO;
		} else if (0 == i) {
			continue;
		}
		length -= i;
		data += i;
	}

	return YES;
}
- (int)sock_recv:(Byte *)buf length:(int)length
{
	if ((sock < 0) || (NULL == buf) || (length <= 0)) {
		return -1;
	}

	fd_set fds_r;
	struct timeval tv;

	tv.tv_sec	= 0;
	tv.tv_usec	= 500;
	FD_ZERO(&fds_r);
	FD_SET(sock, &fds_r);
	int n = select(sock+1, &fds_r, NULL, NULL, &tv);
	if (n <= 0) {
		if (n < 0) {
			if ((EAGAIN != errno) && (EINTR != errno)) {
				[self sock_close];
				return -2;
			}
		}
		return 0;
	}
	if (!FD_ISSET(sock, &fds_r)) {
		return 0;
	}

	int i = recv(sock, buf, length, 0);
	if (i < 0) {
		if ((EAGAIN == errno) || (EINTR == errno)) {
			return 0;
		}
		[self sock_close];
		return -3;
	}

	return i;
}

#pragma mark audio layer

-(void)aud_afmt:(AudioStreamBasicDescription *)afmt
{
	if (NULL == afmt) {
		return;
	}

	memset(afmt, 0, sizeof(AudioStreamBasicDescription));

	afmt->mSampleRate		= 8000.0;
	afmt->mFormatID			= kAudioFormatULaw;
	afmt->mFramesPerPacket	= 1;
	afmt->mChannelsPerFrame	= 1;	
	afmt->mBytesPerFrame	= 1;
	afmt->mBytesPerPacket	= 1;
	afmt->mBitsPerChannel	= 8;
	afmt->mReserved			= 0;
	afmt->mFormatFlags		= kAudioFormatFlagIsPacked;//|kAudioFormatFlagIsSignedInteger;
}

// Takes a filled buffer and writes it to disk, "emptying" the buffer
void aud_recd(void* inUserData, AudioQueueRef inAQ, AudioQueueBufferRef inBuffer, const AudioTimeStamp* inStartTime, UInt32 inNumberPacketDescriptions, const AudioStreamPacketDescription* inPacketDescs)
{
	AudioConference *p = (__bridge AudioConference *)inUserData;
	if (!p->recd.recording) {
		printf("Not recording, returning\n");
		return;
	}

	//printf("Writing buffer %lld\n", recd->currentPacket);
//	int n = inBuffer->mAudioDataByteSize / 2 * 2;
//	short tmp;
//	unsigned char *data = (unsigned char *)inBuffer->mAudioData;
//	for (int i=0; i<n; i+=2) {
//		tmp = data[i] | (data[i+1] << 8);
//		data[i/2] = linear2ulaw(tmp);
//	}
//
//	[p pkt_send:C2S_AUDIODATA data:data length:n/2 recv:FALSE];
	[p pkt_send:C2S_AUDIODATA data:(unsigned char *)inBuffer->mAudioData length:inBuffer->mAudioDataByteSize recv:FALSE];

//	@synchronized (p) {
//		if ([p->rArray count] > 100) {
//			[p->rArray removeObjectAtIndex:0];
//		}
//		[p->rArray addObject:[NSData dataWithBytes:inBuffer->mAudioData length:inBuffer->mAudioDataByteSize]];
//	}

	
	AudioQueueEnqueueBuffer(p->recd.queue, inBuffer, 0, NULL);
}

OSStatus	playback(void *inRefCon, AudioUnitRenderActionFlags *ioActionFlags,
					 const AudioTimeStamp *inTimeStamp, UInt32 inBusNumber, UInt32 inNumberFrames, AudioBufferList *ioData)
{
	AudioConference *p = (__bridge AudioConference *)inRefCon;
	ioData->mNumberBuffers = 1;
	ioData->mBuffers[0].mDataByteSize	= inNumberFrames * p->play.dataFormat.mBytesPerFrame;
	ioData->mBuffers[0].mNumberChannels	= 1;
	if (p->play.playing) {
		@synchronized (p) {
			if (bq_size(p->queue) >= ioData->mBuffers[0].mDataByteSize) {
				int n = bq_read(p->queue, ioData->mBuffers[0].mData, ioData->mBuffers[0].mDataByteSize);
				if (n == ioData->mBuffers[0].mDataByteSize) {
					return 0;
				}
			}
		}
	}
	// write silence
	memset(ioData->mBuffers[0].mData, 0, ioData->mBuffers[0].mDataByteSize);
	return 0;
}
void aud_running(void *inUserData, AudioQueueRef inAQ, AudioQueuePropertyID inID)
{
	//printf("inID: %.2X, %.2X, %.2X, %.2X\n", inID & 0xFF, inID & 0xFF00 >> 8, inID & 0xFF0000 >> 16, inID & 0xFF000000 >> 24);
}

#pragma mark protocol layer

-(acpacket *)pkt_send:(UInt8)seq cmd:(UInt8)cmd data:(Byte *)data length:(UInt16)length recv:(BOOL)recv
{
	if ((NULL == data) && (length > 0)) {
		return NULL;
	}

	int n = 5+length;
	unsigned char *p = (unsigned char *)malloc(n);
	if (NULL == p) {
		return NULL;
	}
	
	memset(p, 0, n);
	p[0]	= '#';
	p[1]	= (unsigned char)((n & 0xFF00) >> 1);
	p[2]	= (unsigned char)(n & 0x00FF);
	p[3]	= (unsigned char)(seq & 0x00FF);
	p[4]	= (unsigned char)(cmd & 0x00FF);
	if (NULL != data) {
		memcpy(p+5, data, length);
	}
	BOOL b = [self sock_send:p length:n];
	free(p);
	if (b && recv) {
		for (int i=0; i<1000 && sock>=0; i++) {
			@synchronized (self) {
				acpacket *pkt = (acpacket *)last;
				if ((NULL != pkt) && (pkt->sequence == seq)) {
					last = NULL;
					return pkt;
				}
			}
			usleep(1000);
		}
	}
	return NULL;
}
-(acpacket *)pkt_send:(UInt8)cmd data:(Byte *)data length:(UInt16)length recv:(BOOL)recv
{
	return [self pkt_send:++sequence cmd:cmd data:data length:length recv:recv];
}
-(acpacket *)pkt_recv:(membufr)mb
{
	int idx = -1;
	for (int i=0; i<mb.used; i++) {
		if ('#' == mb.data[i]) {
			idx = i;
			break;
		}
	}
	if (idx < 0) {
		mb.used = 0;
		return NULL;
	}
	if ((idx+5) > mb.used) {
		if (idx > 0) {
			memmove(mb.data, mb.data+idx, mb.used-idx);
			mb.used -= idx;
		}
		return NULL;
	}
	unsigned short len = (mb.data[idx+1] << 1) + mb.data[idx+2];
	if (len > mb.used) {
		if (idx > 0) {
			memmove(mb.data, mb.data+idx, mb.used-idx);
			mb.used -= idx;
		}
		return NULL;
	}
	acpacket *pkt = (acpacket *)malloc(sizeof(acpacket));
	if (NULL == pkt) {
		return NULL;
	}
	pkt->start_code	= mb.data[idx];
	pkt->length		= len;
	pkt->sequence	= mb.data[idx+3];
	pkt->command	= mb.data[idx+4];
	if (len > 5) {
		pkt->data = (unsigned char *)malloc(pkt->length-5);
		if (NULL == pkt->data) {
			free(pkt);
			return NULL;
		}
		memcpy(pkt->data, &mb.data[idx+5], pkt->length-5);

		int n = idx+pkt->length;
		mb.used -= n;
		memmove(mb.data, mb.data+n, mb.used);
	}
	return pkt;
}
-(void)pkt_free:(acpacket *)pkt
{
	if (NULL != pkt) {
		if (NULL != pkt->data) {
			free(pkt->data);
		}
		free(pkt);
	}
}
-(BOOL)pkt_isok_and_free:(acpacket *)pkt
{
	if (NULL != pkt) {
		if ((S2C_CLIENTRESP == pkt->command) && (NULL != pkt->data) && (0x01 == pkt->data[0])) {
			[self pkt_free:pkt];
			return YES;
		}
		[self pkt_free:pkt];
	}
	return NO;
}

-(BOOL)pkt_goroom:(NSString *)host port:(UInt16)port roomID:(UInt32)roomID randCode:(NSString *)randCode
{
	char buf[256];
	membufr mbuf;
	mbuf.size	= sizeof(buf);
	mbuf.data	= (unsigned char *)buf;
	mbuf.used	= 0;

	memset(buf, 0, sizeof(buf));
	snprintf(buf, sizeof(buf)-1, "GET /Sys/AConf?roomID=%lu&randCode=%s HTTP/1.1\r\n"\
			 "Host: %s:%d\r\n"\
			 "Connection: keep-alive\r\n"\
			 "\r\n", roomID, [randCode UTF8String], [host UTF8String], port);
	if (![self sock_send:(Byte *)buf length:strlen(buf)]) {
		return NO;
	}
	for (int i=0; i<100; i++) {
		int n = [self sock_recv:mbuf.data+mbuf.used length:mbuf.size-mbuf.used];
		if (n < 0) {
			return NO;
		}
		mbuf.used += n;
		acpacket* pkt = [self pkt_recv:mbuf];
		if (NULL == pkt) {
			continue;
		}
		if ((S2C_CLIENTRESP == pkt->command) && (NULL != pkt->data) && (0x01 == pkt->data[0])) {
			[self pkt_free:pkt];
			return YES;
		}
		[self pkt_free:pkt];
		break;
	}
	return NO;
}

-(void)pkt_thread:(void *)arg
{
	Byte bufr[512];
	membufr mbuf;
	acpacket *pkt;

	memset(&mbuf, 0, sizeof(mbuf));
	mbuf.size = 1024;
	mbuf.data = (unsigned char *)malloc(mbuf.size);
	if (NULL == mbuf.data) {
		return;
	}
	while (bConnected) {
		int n = [self sock_recv:bufr length:sizeof(bufr)];
		if (n <= 0) {
			continue;
		}
		if ((mbuf.used+n) > mbuf.size) {
			unsigned int size = mbuf.used+n*2;
			unsigned char *p = (unsigned char *)realloc(mbuf.data, size);
			if (NULL == p) {
				break;
			}
			mbuf.size	= size;
			mbuf.data	= p;
		}
		memcpy(mbuf.data+mbuf.used, bufr, n);
		mbuf.used += n;
		pkt = [self pkt_recv:mbuf];
		if (NULL != pkt) {
			if (S2C_AUDIODATA == pkt->command) {
				int n = pkt->length - 5;
				if (play.playing && (n > 0)) {
					// append the audio data into buffer, wait aud_play retrieve
					unsigned char *raw = ulaw2linear_batch(pkt->data, n);
					@synchronized (self) {
						bq_write(queue, raw, n*2);
					}
					free(raw);
				}
				[self pkt_free:pkt];
			} else if (S2C_BROADCAST == pkt->command) {
				dispatch_async(dispatch_get_main_queue(), ^{
					//连接成功的回调
					if (self.delegate && [self.delegate respondsToSelector:@selector(broadcastPacket:data:length:)]) {
						[self.delegate broadcastPacket:self data:pkt->data length:pkt->length-5];
					}
					[self pkt_free:pkt];
				});
			} else {
				@synchronized (self) {
					if (NULL != last) {
						[self pkt_free:(acpacket *)last];
					}
					last = pkt;
				}
			}
		}
	}
	if (NULL != mbuf.data) {
		free(mbuf.data);
	}
}

#pragma mark export functions

-(id)init
{
	if (self = [super init]) {
		sequence = 0;
		bConnected = NO;
		queue = bq_new();
	}
	return self;
}

- (void)connect:(NSString *)host port:(int)port roomID:(UInt32)roomID randCode:(NSString *)randCode
{
//	[self close];
	dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
		// socket连接服务器
		BOOL a = [self sock_connect:host port:port];
		BOOL b = [self pkt_goroom:host port:port roomID:roomID randCode:randCode];
		if (a && b) {
			dispatch_async(dispatch_get_main_queue(), ^{
				//连接成功的回调
				if (self.delegate && [self.delegate respondsToSelector:@selector(connected:)]) {
					[self.delegate connected:self];
				}
			});
			[NSThread detachNewThreadSelector:@selector(pkt_thread:) toTarget:self withObject:self];
		} else {
			[self close];
			dispatch_async(dispatch_get_main_queue(), ^{
				//连接失败
				if (self.delegate && [self.delegate respondsToSelector:@selector(conerror:)]) {
					[self.delegate conerror:self];
				}
			});
		}
	});
}

- (void)close
{
	[self closeUpStream];
	[self closeDownStream];
	[self sock_close];
}

- (BOOL)openUpStream
{
	if (recd.recording) {
		return YES;
	}

	acpacket *pkt = [self pkt_send:C2S_TALK_START data:NULL length:0 recv:TRUE];
	if (![self pkt_isok_and_free:pkt]) {
		return NO;
	}

	[self aud_afmt:&recd.dataFormat];

	OSStatus status;
	status = AudioQueueNewInput(&recd.dataFormat, aud_recd, (__bridge void*)self, NULL, NULL, 0, &recd.queue);
	if (status == 0) {
		// Prime recording buffers with empty data
		for (int i = 0; i < NUM_BUFFERS; i++) {
			AudioQueueAllocateBuffer(recd.queue, 320, &recd.buffers[i]);
			AudioQueueEnqueueBuffer(recd.queue, recd.buffers[i], 0, NULL);
		}
		//Float32 vol = 0.0;
		//status = AudioQueueSetParameter(play.queue, kAudioQueueParam_Volume, vol);
		status = AudioQueueStart(recd.queue, NULL);
		if (status == 0) {
			recd.recording = true;
			return YES;
		}
	}
	[self closeUpStream];
	return NO;
}
- (void)closeUpStream
{
	recd.recording = false;
	[self pkt_send:C2S_TALK_STOP data:NULL length:0 recv:FALSE];
	AudioQueueStop(recd.queue, true);
	for(int i = 0; i < NUM_BUFFERS; i++) {
		AudioQueueFreeBuffer(recd.queue, recd.buffers[i]);
	}
	AudioQueueDispose(recd.queue, true);
}

- (BOOL)openDownStream
{
	if (play.playing) {
		return YES;
	}

//	for (int i=0; i<NUM_BUFFERS; i++) {
//		play.bufusing[i] = true;
//	}

	OSStatus status;
	AudioComponentInstance audioUnit;

	// Describe audio component
	AudioComponentDescription desc;
	desc.componentType			= kAudioUnitType_Output;
	desc.componentSubType		= kAudioUnitSubType_RemoteIO;
	desc.componentFlags			= 0;
	desc.componentFlagsMask		= 0;
	desc.componentManufacturer	= kAudioUnitManufacturer_Apple;
	// Get component
	AudioComponent inputComponent = AudioComponentFindNext(NULL, &desc);
	
	// Get audio units
	status = AudioComponentInstanceNew(inputComponent, &audioUnit);
	if (0 != status) {
		return NO;
	}

	// Enable IO for recording
	UInt32 flag = 1;
//	status = AudioUnitSetProperty(audioUnit, kAudioOutputUnitProperty_EnableIO, kAudioUnitScope_Input, kInputBus, &flag, sizeof(flag));
//	if (0 != status) {
//		AudioComponentInstanceDispose(audioUnit);
//		return NO;
//	}
	// Enable IO for playback
	status = AudioUnitSetProperty(audioUnit, kAudioOutputUnitProperty_EnableIO, kAudioUnitScope_Output, kOutputBus, &flag, sizeof(flag));
	if (0 != status) {
		AudioComponentInstanceDispose(audioUnit);
		return NO;
	}

	[self aud_afmt:&play.dataFormat];
	play.dataFormat.mSampleRate			= 8000.00;
	play.dataFormat.mFormatID			= kAudioFormatLinearPCM;
	play.dataFormat.mFramesPerPacket	= 1;
	play.dataFormat.mChannelsPerFrame	= 1;
	play.dataFormat.mBytesPerFrame		= 2;
	play.dataFormat.mBytesPerPacket		= 2;
	play.dataFormat.mBitsPerChannel		= 16;
	play.dataFormat.mReserved			= 0;
	play.dataFormat.mFormatFlags		= kAudioFormatFlagIsSignedInteger|kAudioFormatFlagIsPacked;

	// Apply format
	status = AudioUnitSetProperty(audioUnit, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Output, kInputBus, &play.dataFormat, sizeof(play.dataFormat));
	if (0 != status) {
		AudioComponentInstanceDispose(audioUnit);
		return NO;
	}
	status = AudioUnitSetProperty(audioUnit, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Input, kOutputBus, &play.dataFormat, sizeof(play.dataFormat));
	if (0 != status) {
		AudioComponentInstanceDispose(audioUnit);
		return NO;
	}

	// Set input callback
	AURenderCallbackStruct callback;
//	callback.inputProc		= recording;
//	callback.inputProcRefCon= (__bridge void *)(self);
//	status = AudioUnitSetProperty(audioUnit, kAudioOutputUnitProperty_SetInputCallback, kAudioUnitScope_Global, kInputBus, &callback, sizeof(callback));
//	if (0 != status) {
//		AudioComponentInstanceDispose(audioUnit);
//		return NO;
//	}
	// Set output callback
	callback.inputProc		= playback;
	callback.inputProcRefCon= (__bridge void *)(self);
	status = AudioUnitSetProperty(audioUnit, kAudioUnitProperty_SetRenderCallback, kAudioUnitScope_Global, kOutputBus, &callback, sizeof(callback));
	if (0 != status) {
		AudioComponentInstanceDispose(audioUnit);
		return NO;
	}

	// Disable buffer allocation for the recorder (optional - do this if we want to pass in our own)
//	flag = 0;
//	status = AudioUnitSetProperty(audioUnit, kAudioUnitProperty_ShouldAllocateBuffer, kAudioUnitScope_Output, kInputBus, &flag, sizeof(flag));
	// Initialise
	status = AudioUnitInitialize(audioUnit);
	if (0 != status) {
		AudioComponentInstanceDispose(audioUnit);
		return NO;
	}

	status = AudioOutputUnitStart(audioUnit);
	if (0 != status) {
		AudioComponentInstanceDispose(audioUnit);
		return NO;
	}

	acpacket *pkt = [self pkt_send:C2S_LISTEN_START data:NULL length:0 recv:TRUE];
	if (![self pkt_isok_and_free:pkt]) {
		AudioComponentInstanceDispose(audioUnit);
		return NO;
	}

	play.playing = TRUE;

	return YES;
}
- (void)closeDownStream
{
    play.playing = false;
	[self pkt_send:C2S_LISTEN_STOP data:NULL length:0 recv:FALSE];
	for(int i = 0; i < NUM_BUFFERS; i++) {
		AudioQueueFreeBuffer(play.queue, play.buffers[i]);
	}
	AudioQueueDispose(play.queue, true);
}

@end